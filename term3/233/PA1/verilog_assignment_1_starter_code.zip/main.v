module main(A, B, multiply, Result, Cout);
    input [3:0] A;
    input [1:0] B;
    input multiply;
    output [4:0] Result;
    output Cout;

    // Your code goes here.  DO NOT change anything that is already given! Otherwise, you will not be able to pass the tests!

endmodule
