module five_bit_rca(
    input [4:0] A,
    input [4:0] B,
    input Cin,
    output [4:0] S,
    output Cout
);

    // Your code goes here.  DO NOT change anything that is already given! Otherwise, you will not be able to pass the tests!

endmodule