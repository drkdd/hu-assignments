module multiplier (
    input [3:0] A,
    input [1:0] B,
    output [3:0] p1,
	output [4:0] p2_shifted
);
    
    // Your code goes here.  DO NOT change anything that is already given! Otherwise, you will not be able to pass the tests!

endmodule  
