`timescale 1s/1ms
// ============================================================
// dead_hand.v  (STUDENT STARTER CODE)
// BBM233 Logic Design Laboratory
// Final Project: World War III – Dead Hand Protocol
//
// IMPORTANT:
// - Do NOT change module name or port list.
// - clk is 1 Hz (1 tick per second).
// - reset is synchronous, active-high.
// - Implement Main FSM + Engagement Sub-FSM.
// ============================================================

module dead_hand(
    input  wire       clk,
    input  wire       reset,
    input  wire [1:0] threat_level,
    input  wire       diplomatic_override,
    input  wire       comms_lost,
    input  wire       system_fault,

    output reg        armed_out,
    output reg        tracking_out,
    output reg        authorization_out,
    output reg        override_ignored,
    output reg [2:0]  main_state_out,
    output reg [1:0]  sub_state_out,
    output reg [31:0] timer_out
);
// Your code starts from here.
endmodule

