//--------------------------------------------------------------
// alu.sv
// 32-bit ALU for MIPS processor
// ALU Control (f):
//   000: AND
//   001: OR
//   010: ADD
//   110: SUB
//   111: SLT (set on less than)
//--------------------------------------------------------------

module alu(input  logic [31:0] a, b,
           input  logic [2:0]  f,
           output logic [31:0] y,
           output logic        zero);

  logic [31:0] b2, sum;
  logic        slt;

  assign b2  = f[2] ? ~b : b;          // invert b for SUB/SLT
  assign sum = a + b2 + f[2];           // single adder: add or subtract

  // SLT: signed comparison a < b
  // If signs differ: a<b iff a is negative
  // If signs same:   a<b iff (a-b) is negative
  assign slt = (a[31] ^ b[31]) ? a[31] : sum[31];

  always_comb
    case (f)
      3'b000:  y = a & b;       // AND
      3'b001:  y = a | b;       // OR
      3'b010:  y = sum;         // ADD
      3'b110:  y = sum;         // SUB
      3'b111:  y = {31'b0, slt}; // SLT
      default: y = 32'bx;
    endcase

  assign zero = (y == 32'b0);

endmodule
