.data
A:      .word 495, 10, 864, 22, 0, 24
size:   .word 6
thresh: .word 40

        .text
        .globl main
main:
        # TODO: Part 1 — decrypt the array (50 pts)
        #   for (int i = 0; i < datasize; i++)
        #       if (i % 2 == 0) data[i] = data[i] / 9;
        #       else            data[i] = data[i] * 3;
        #   No mul/mult/div allowed (-10 penalty)


        # TODO: Print and count (see instructions for output format)


        li   $v0, 10
        syscall

# Do NOT rename this label
count_suspicious:
        # TODO: Part 2 — recursive count (50 pts)
        #   int count_suspicious(int *data, int n, int threshold)
        #   $a0 = array, $a1 = n, $a2 = threshold, return in $v1
        #   Must use jal, must be recursive