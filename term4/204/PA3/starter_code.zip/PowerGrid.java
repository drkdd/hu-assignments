import java.util.List;

public class PowerGrid {

    public static boolean isConnected(Graph g) {
        throw new UnsupportedOperationException("Not implemented yet");
    }

    public static List<Edge> kruskalMST(Graph g) {
        throw new UnsupportedOperationException("Not implemented yet");
    }
}
