import java.util.List;

public class BootSequence {

    public static List<Integer> computeBootSequence(Digraph g, String[] labels) {
        throw new UnsupportedOperationException("Not implemented yet");
    }
}
