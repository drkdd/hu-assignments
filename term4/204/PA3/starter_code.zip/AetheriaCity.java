import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import java.io.File;

/**
 * AetheriaCity – Main entry point.
 *
 * Parse AetheriaCity.xml, build the required graphs, and call your
 * implementations in sequence.
 *
 * Usage:
 *   javac *.java -d .
 *   java AetheriaCity <AetheriaCity>
 */
public class AetheriaCity {

    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.err.println("Usage: java AetheriaCity <xml-file>");
            return;
        }
        Document doc = parseXML(args[0]);

        // TODO: Parse <districts>, build Graph, call PowerGrid
        // TODO: Parse <bootDependencies>, build Digraph, call BootSequence
        // TODO: Parse <fiberLinks>, build Digraph, call CommHubs
        // TODO: Parse <leakScenarios>, call BioLeakContainment
    }

    // ── XML helpers ──────────────────────────────────────────────────

    private static Document parseXML(String filename) throws Exception {
        File file = new File(filename + ".xml");
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(file);
        doc.getDocumentElement().normalize();
        return doc;
    }

    private static String getText(Element parent, String tag) {
        NodeList nl = parent.getElementsByTagName(tag);
        if (nl.getLength() == 0) return "";
        return nl.item(0).getTextContent().trim();
    }

    static void printBanner(String title) {
        String line = "═".repeat(60);
        System.out.println("\n" + line);
        System.out.println("  " + title);
        System.out.println(line);
    }
}
