import java.util.List;

public class BioLeakContainment {

    public static List<Integer> dfsReachable(Digraph g, int source, String[] labels) {
        throw new UnsupportedOperationException("Not implemented yet");
    }

    public static List<List<Integer>> bfsLayers(Digraph g, int source, String[] labels) {
        throw new UnsupportedOperationException("Not implemented yet");
    }
}
