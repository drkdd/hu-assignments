import java.util.*;

public class SpaceportTransitPlanner {

    Map<Station, Station> prev = new HashMap<>();
    Map<String, Double> cost = new HashMap<>();

    double dist(Station a, Station b) {
        double dx = a.p.x - b.p.x;
        double dy = a.p.y - b.p.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    void addUndirected(Station a, Station b, double speed) {
        // TODO: Add bidirectional walking edge
    }

    void addDirected(Station a, Station b, double speed) {
        // TODO: Add directed shuttle edge
    }

    public List<RouteInstruction> solve(SpaceportTransitNetwork net) {
        List<RouteInstruction> route = new ArrayList<>();

        // TODO:
        // 1. Build graph
        // 2. Add walking edges
        // 3. Add directed shuttle edges
        // 4. Run Dijkstra
        // 5. Reconstruct path

        return route;
    }

    public void print(List<RouteInstruction> r) {
        // TODO: Print route exactly in required format
    }
}