import java.util.*;

public class Station {
    Point p;
    String name;
    List<Edge> edges = new ArrayList<>();

    public Station(Point p, String n) {
        this.p = p;
        name = n;
    }
}