import java.util.*;
import java.util.regex.*;

public class SpaceportTransitNetwork {

    double shuttleSpeed;
    final double walkSpeed = 1000 / 6.0;

    Station start, end;
    List<ShuttleCorridor> corridors;

    String content;

    int getInt(String v) {
        Pattern p = Pattern.compile(v + "\\s*=\\s*([0-9]+)");
        Matcher m = p.matcher(content);
        m.find();
        return Integer.parseInt(m.group(1));
    }

    double getDouble(String v) {
        // TODO: Regex for double
        return 0;
    }

    Point getPoint(String v) {
        // TODO: Regex for point (x,y)
        return null;
    }

    List<ShuttleCorridor> parseCorridors() {
        List<ShuttleCorridor> list = new ArrayList<>();
        // TODO: Parse corridor names and stations
        return list;
    }

    void readInput(String f) {
        // TODO: Read file and initialize variables
    }
}