public class Edge implements Comparable<Edge> {
    Station to;
    double w;

    public Edge(Station t, double w) {
        to = t;
        this.w = w;
    }

    public int compareTo(Edge o) {
        return Double.compare(this.w, o.w);
    }
}