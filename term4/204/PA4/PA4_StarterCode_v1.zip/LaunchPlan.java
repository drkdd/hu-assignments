import java.util.*;

public class LaunchPlan {

    String name;
    List<Operation> ops;

    public LaunchPlan(String n, List<Operation> o) {
        name = n;
        ops = o;
    }

    /**
     * Computes the earliest possible start times for all operations.
     * You should consider dependency constraints between operations.
     */
    public int[] earliest() {
        // TODO: Implement topological sorting + scheduling
        return null;
    }

    /**
     * Computes total time required to complete all operations.
     */
    public int total(int[] schedule) {
        // TODO: Compute maximum finish time
        return 0;
    }

    /**
     * Helper function to print separator line
     */
    public static void printLine(int n) {
        for (int i = 0; i < n; i++) System.out.print("-");
        System.out.println();
    }

    /**
     * Prints the launch plan timeline in required format.
     */
    public void print() {

        int[] schedule = earliest();

        int width = 65;

        printLine(width);
        System.out.println("Launch Plan: " + name);
        printLine(width);

        // Header
        System.out.printf("%-8s%-35s%-8s%-8s\n", "Code", "Operation", "Begin", "Finish");

        printLine(width);

        // TODO:
        // Print each operation with:
        // code, label, start time, finish time

        printLine(width);

        // TODO:
        // Print total duration in format:
        // Launch-ready in X hour(s).

        printLine(width);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LaunchPlan)) return false;

        LaunchPlan other = (LaunchPlan) o;

        return name.equals(other.name) && ops.equals(other.ops);
    }
}