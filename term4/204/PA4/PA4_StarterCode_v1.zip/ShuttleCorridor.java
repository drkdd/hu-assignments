import java.util.*;

public class ShuttleCorridor {
    String name;
    List<Station> stations;

    public ShuttleCorridor(String n, List<Station> s) {
        name = n;
        stations = s;
    }
}